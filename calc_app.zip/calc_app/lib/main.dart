import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Calculator',
      home: new CalculatorPage(),
    );
  }
}

class CalculatorPage extends StatefulWidget {
  @override
  _CalculatorPageState createState() => new _CalculatorPageState();
}

class _CalculatorPageState extends State<CalculatorPage> {
  String output = "0";

  String _output = "0";
  double num1 = 0.0;
  double num2 = 0.0;
  String operand = "";

  buttonPressed(String buttonText) {
    if (buttonText == "CLEAR") {
      _output = "0";
      num1 = 0.0;
      num2 = 0.0;
      operand = "";
    } else if (buttonText == "+" ||
        buttonText == "-" ||
        buttonText == "/" ||
        buttonText == "X") {
      num1 = double.parse(output);

      operand = buttonText;

      _output = "0";
    } else if (buttonText == ".") {
      if (_output.contains(".")) {
        print("Already conatains a decimals");
        return;
      } else {
        _output = _output + buttonText;
      }
    } else if (buttonText == "=") {
      num2 = double.parse(output);

      if (operand == "+") {
        _output = (num1 + num2).toString();
      }
      if (operand == "-") {
        _output = (num1 - num2).toString();
      }
      if (operand == "X") {
        _output = (num1 * num2).toString();
      }
      if (operand == "/") {
        _output = (num1 / num2).toString();
      }

      num1 = 0.0;
      num2 = 0.0;
      operand = "";
    } else {
      _output = _output + buttonText;
    }

    print(_output);

    setState(() {
      output = double.parse(_output).toStringAsFixed(2);
    });
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      body: Container(
        height: double.infinity,
        width: double.infinity,
        color: Colors.white,
        child: new Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Flexible(
                  flex: 3,
                  child: Container(
                    color: Colors.white,
                    child: new Column(children: <Widget>[
                      new Text(output),
                      new Container(
                          alignment: Alignment.centerRight,
                          padding: new EdgeInsets.symmetric(
                              vertical: 24.0, horizontal: 12.0))
                    ]),
                  )),
              Flexible(
                child: Container(
                  color: Colors.white12,
                  child: new Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        //First Row
                        Flexible(
                          flex: 1,
                          child: new Container(
                            height: double.infinity,
                            width: double.infinity,
                            child: new Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Flexible(flex: 1, child: CustomButton("M+")),
                                Flexible(flex: 1, child: CustomButton("M-")),
                                Flexible(flex: 1, child: CustomButton("MR")),
                                Flexible(flex: 1, child: CustomButton("MC")),
                                Flexible(flex: 1, child: CustomButton("+/-")),
                              ],
                            ),
                          ),
                        ),

                        //Second row
                        Flexible(
                          flex: 1,
                          child: new Container(
                            height: double.infinity,
                            width: double.infinity,
                            child: new Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Flexible(flex: 1, child: CustomButton("%")),
                                Flexible(flex: 1, child: CustomButton("7")),
                                Flexible(flex: 1, child: CustomButton("8")),
                                Flexible(flex: 1, child: CustomButton("9")),
                                Flexible(flex: 1, child: CustomButton("/"))
                              ],
                            ),
                          ),
                        ),

                        //Third Row
                        Flexible(
                          flex: 1,
                          child: new Container(
                            height: double.infinity,
                            width: double.infinity,
                            child: new Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Flexible(
                                    flex: 1, child: CustomButton("\u221A")),
                                Flexible(flex: 1, child: CustomButton("4")),
                                Flexible(flex: 1, child: CustomButton("5")),
                                Flexible(flex: 1, child: CustomButton("6")),
                                Flexible(flex: 1, child: CustomButton("x"))
                              ],
                            ),
                          ),
                        ),

                        //Fourth Row
                        Flexible(
                          flex: 1,
                          child: new Container(
                            height: double.infinity,
                            width: double.infinity,
                            child: new Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Flexible(flex: 1, child: CustomButton("%")),
                                Flexible(flex: 1, child: CustomButton("1")),
                                Flexible(flex: 1, child: CustomButton("2")),
                                Flexible(flex: 1, child: CustomButton("3")),
                                Flexible(flex: 1, child: CustomButton("-"))
                              ],
                            ),
                          ),
                        ),

                        //Fifth Row
                        Flexible(
                          flex: 1,
                          child: new Container(
                            height: double.infinity,
                            width: double.infinity,
                            child: new Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Flexible(flex: 1, child: CustomButton("CE")),
                                Flexible(flex: 1, child: CustomButton("0")),
                                Flexible(flex: 1, child: CustomButton(".")),
                                Flexible(flex: 1, child: CustomButton("=")),
                                Flexible(flex: 1, child: CustomButton("+")),
                              ],
                            ),
                          ),
                        ),
                      ]),
                ),
                flex: 5,
              )
            ]),
      ),
    );
  }
}

class CustomButton extends StatelessWidget {
  String text;

  CustomButton(this.text);

  @override
  Widget build(BuildContext context) {
    return new Container(
      margin: new EdgeInsets.all(6.0),
      height: double.infinity,
      width: double.infinity,
      alignment: Alignment.center,
      decoration: new BoxDecoration(
          borderRadius: new BorderRadius.all(new Radius.circular(16.0)),
          color: Colors.white24),
      child: new Text(
        text,
        style: new TextStyle(color: Colors.black, fontSize: 26.0),
      ),
    );
  }
}
